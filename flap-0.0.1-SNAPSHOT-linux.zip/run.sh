#!/bin/bash
java -Dscage.properties=flappy.properties -Djava.library.path=native -DLWJGL_DISABLE_XRANDR=true -Dfile.encoding=UTF-8 -jar lib/flap-0.0.1-SNAPSHOT.jar